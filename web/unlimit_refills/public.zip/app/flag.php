<?php 

$flag = "KCTF{this_is_fake_flag}";

?>
