#!/bin/bash

# starting flask server
nohup python3 -u /app/app.py &> /<**DELETE**>.out