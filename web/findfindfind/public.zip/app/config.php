<?php 

$conn = new mysqli("find_mysql", "kctf", "autoset", "user");
$flag = "KCTF{this_is_fake_flag}";

?>
